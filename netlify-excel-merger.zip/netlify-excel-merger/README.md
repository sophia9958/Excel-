# Excel 多工作表合并工具

一个本地浏览器处理的 Excel 多 sheet 合并网页工具。

## 文件说明

- `index.html`：Netlify/GitHub Pages 可直接部署的入口文件。

## Netlify 部署

方式一：直接把整个 `netlify-excel-merger` 文件夹拖到 Netlify Drop。

方式二：上传到 GitHub 仓库后，在 Netlify 选择从 GitHub 部署。

## 注意

当前版本通过 CDN 加载 `xlsx.full.min.js`。如果使用环境无法访问 CDN，需要改成离线版，把依赖文件放到本地并修改 script 路径。
